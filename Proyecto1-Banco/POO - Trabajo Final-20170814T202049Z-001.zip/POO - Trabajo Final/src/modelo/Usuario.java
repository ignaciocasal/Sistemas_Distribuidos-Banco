package modelo;

public class Usuario {
	private String nombreUser;
	private String apellidoUser;
	private String idUser;
	private String passUser;
	private Boolean isAdmin;
	private Boolean isActivo;

	public Usuario() {
		// TODO Auto-generated constructor stub
	}

	public Usuario(String nombreUser, String apellidoUser, String idUser, String passUser, Boolean isAdmin, Boolean isActivo) {
		this.nombreUser = nombreUser;
		this.apellidoUser = apellidoUser;
		this.idUser = idUser;
		this.passUser = passUser;
		this.isAdmin = isAdmin;
		this.isActivo = isActivo;
	}

	public String getnombreUser() {
		return nombreUser;
	}

	public void setnombreUser(String nombreUser) {
		this.nombreUser = nombreUser;
	}

	public String getidUser() {
		return idUser;
	}

	public void setidUser(String idUser) {
		this.idUser = idUser;
	}

	public String getpassUser() {
		return passUser;
	}

	public void setpassUser(String passUser) {
		this.passUser = passUser;
	}

	public String getapellidoUser() {
		return apellidoUser;
	}

	public void setapellidoUser(String apellidoUser) {
		this.apellidoUser = apellidoUser;
	}

	public Boolean getIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(Boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public Boolean getIsActivo() {
		return isActivo;
	}

	public void setIsActivo(Boolean isActivo) {
		this.isActivo = isActivo;
	}

}
