package modelo;

public class Producto {

	private String nombreProd;
	private String marcaProd;
	private Integer idProducto;
	private Integer cantidadProd;
	private Double precioProd;
	private Boolean isActivo;
	private Integer puntoPedido;
	// private Boolean requierePedido;

	// CONSTRUCTOR
	public Producto() {

	}

	public Producto(Integer idProducto, String nombre, String marca, Double precio, Integer cantidad,
			Boolean isActivo, Integer puntoPedido) {
		super();
		this.idProducto = idProducto;
		this.nombreProd = nombre;
		this.marcaProd = marca;
		this.precioProd = precio;
		this.cantidadProd = cantidad;
		this.isActivo = isActivo;
		this.puntoPedido = puntoPedido;
	}

	public Integer getIdProducto() {
		return idProducto;
	}

	public void setIdProducto(Integer idProducto) {
		this.idProducto = idProducto;
	}

	public String getNombre() {
		return nombreProd;
	}

	public void setNombreProd(String nombre) {
		this.nombreProd = nombre;
	}

	public String getMarcaProd() {
		return marcaProd;
	}

	public void setMarcaProd(String marca) {
		this.marcaProd = marca;
	}

	public Integer getCantidadProd() {
		return cantidadProd;
	}

	public void setCantidadProd(Integer cantidad) {
		this.cantidadProd = cantidad;
	}

	public Double getPrecioProd() {
		return precioProd;
	}

	public void setPrecioProd(Double precio) {
		this.precioProd = precio;
	}

	public Boolean getIsActivo() {
		return isActivo;
	}

	public void setIsActivo(Boolean isActivo) {
		this.isActivo = isActivo;
	}

	public Integer getPuntoPedido() {
		return puntoPedido;
	}

	public void setPuntoPedido(Integer puntoPedido) {
		this.puntoPedido = puntoPedido;
	}

}
