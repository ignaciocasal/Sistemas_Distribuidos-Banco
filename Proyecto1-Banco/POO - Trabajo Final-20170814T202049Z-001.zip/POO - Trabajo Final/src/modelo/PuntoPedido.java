package modelo;

public class PuntoPedido extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void verificarPuntoPedido(String[] prod) throws PuntoPedido {
		if (Integer.valueOf(prod[4]) < Integer.valueOf(prod[5])) {
			throw new PuntoPedido();

		}

	}

}
