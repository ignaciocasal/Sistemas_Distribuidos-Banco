package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

import modelo.Usuario;
import modelo_db.DataAccess;
import modelo_db.UsuarioDataAccess;
import vista.AgregarUser;
import vista.BusquedaUser;

public class ControladorUsuario implements ActionListener {

	private final BusquedaUser dialogUser;
	private AgregarUser agregar;
	private Usuario usuarioActual;

	public static enum Acciones {
		BTNAGREGAR, BTNMODIFICAR, BTNELIMINAR, BTNBUSCAR, BTNREGISTRAR, BTNFINALIZAR
	}

	public ControladorUsuario() {
		// Inicializacion
		this.dialogUser = new BusquedaUser();
		this.dialogUser.setVisible(true);
		this.agregar = new AgregarUser();

		// Skin tipo WINDOWS
		try {
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
			SwingUtilities.updateComponentTreeUI(dialogUser);
		} catch (Exception ex) {
			// Falla silenciosamente.
		}

		this.dialogUser.getBtnBuscar().addActionListener(this);
		this.dialogUser.getBtnBuscar().setActionCommand(Acciones.BTNBUSCAR.name());
		this.dialogUser.getBtnAgregar().addActionListener(this);
		this.dialogUser.getBtnAgregar().setActionCommand(Acciones.BTNAGREGAR.name());
		this.dialogUser.getBtnEliminar().addActionListener(this);
		this.dialogUser.getBtnEliminar().setActionCommand(Acciones.BTNELIMINAR.name());
		this.dialogUser.getBtnModificar().addActionListener(this);
		this.dialogUser.getBtnModificar().setActionCommand(Acciones.BTNMODIFICAR.name());
		this.dialogUser.getBtnFinalizar().addActionListener(this);
		this.dialogUser.getBtnFinalizar().setActionCommand(Acciones.BTNFINALIZAR.name());
		this.agregar.getBtnRegistrar().addActionListener(this);
		this.agregar.getBtnRegistrar().setActionCommand(Acciones.BTNREGISTRAR.name());

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		switch (Acciones.valueOf(e.getActionCommand())) {
		case BTNAGREGAR:

			this.agregar.setVisible(true);

			break;

		case BTNBUSCAR:
			String busqueda;
			String user[] = null;
			busqueda = this.dialogUser.getTxtFieldUsuario().getText();
			ArrayList<String[]> arrayListUsers = new ArrayList<String[]>();
			if (this.dialogUser.getRdbtnId().isSelected()) {
				DataAccess.limpiarTabla(dialogUser.getTableUsuarios());
				user = UsuarioDataAccess.buscarUsuarioID(busqueda);
				if (user != null) {
					this.dialogUser.getModelo().addRow(user);
					this.dialogUser.getTableUsuarios().setModel(dialogUser.getModelo());
				}
			} else if (this.dialogUser.getRdbtnNombre().isSelected()) {
				DataAccess.limpiarTabla(dialogUser.getTableUsuarios());
				arrayListUsers = (UsuarioDataAccess.buscarUsuarioApellido(busqueda));

				for (String[] userSacado : arrayListUsers) {
					this.dialogUser.getModelo().addRow(userSacado);
				}
				this.dialogUser.getTableUsuarios().setModel(dialogUser.getModelo());

			} else {
				JOptionPane.showMessageDialog(null, "Por favor seleccione un criterio de b�squeda", "Atenci�n",
						JOptionPane.WARNING_MESSAGE);
			}
			if (arrayListUsers.isEmpty() && user == null) {
				JOptionPane.showMessageDialog(null, "No se encontraron resultados", "Atenci�n",
						JOptionPane.WARNING_MESSAGE);
			}

			break;

		case BTNELIMINAR:
			if (!dialogUser.algunRowSelected(dialogUser.getTableUsuarios())) {
				JOptionPane.showMessageDialog(null,
						"No ha seleccionado ningun usuario. Por favor seleccione el que desee eliminar", "Atenci�n",
						JOptionPane.WARNING_MESSAGE);
			} else {
				if (JOptionPane.showConfirmDialog(null, "�Esta seguro que desea eliminar?", "Confirmar Eliminaci�n",
						JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == 0) {
					Integer userRow = dialogUser.getTableUsuarios().getSelectedRow();
					String idUser = String.valueOf(dialogUser.getTableUsuarios().getValueAt(userRow, 3));
					UsuarioDataAccess.eliminarUsuario(idUser);
				}
			}
			break;

		case BTNMODIFICAR:

			JOptionPane.showMessageDialog(null, "Ha habilitado la edici�n", "Edici�n activada",
					JOptionPane.INFORMATION_MESSAGE);
			this.dialogUser.getTableUsuarios().setEnabled(true);
			this.dialogUser.getBtnAgregar().setVisible(false);
			this.dialogUser.getBtnModificar().setVisible(false);
			this.dialogUser.getBtnEliminar().setVisible(true);
			this.dialogUser.getBtnFinalizar().setVisible(true);

			break;

		case BTNREGISTRAR:
			Usuario newUser = new Usuario();
			newUser.setidUser(this.agregar.getTfId().getText());
			newUser.setnombreUser(this.agregar.getTfNombre().getText());
			newUser.setapellidoUser(this.agregar.getTfApellido().getText());
			newUser.setpassUser(this.agregar.getPasswordField().getPassword().toString());
			newUser.setIsAdmin(this.agregar.getChckbxAdmin().isSelected());
			UsuarioDataAccess.registrarUsuario(newUser);
			this.dialogUser.setModelo(UsuarioDataAccess.bajarTabla());
			this.dialogUser.getTableUsuarios().setModel(dialogUser.getModelo());
			this.agregar.setVisible(false);
			break;

		case BTNFINALIZAR:
			this.dialogUser.getTableUsuarios().setEnabled(false);
			this.dialogUser.getBtnAgregar().setVisible(true);
			this.dialogUser.getBtnModificar().setVisible(true);
			this.dialogUser.getBtnEliminar().setVisible(false);
			this.dialogUser.getBtnFinalizar().setVisible(false);

			break;
		default:
			break;

		}

	}

	public Usuario getUsuarioActual() {
		return usuarioActual;
	}

	public void setUsuarioActual(Usuario usuarioActual) {
		this.usuarioActual = usuarioActual;
	}

	public BusquedaUser getDialogUser() {
		return dialogUser;
	}

	public AgregarUser getAgregar() {
		return agregar;
	}

}
