package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import modelo.Producto;
import modelo.PuntoPedido;
import modelo.Usuario;
import modelo_db.DataAccess;
import modelo_db.ProductoDataAccess;
import modelo_db.UsuarioDataAccess;
import vista.AgregarProd;
import vista.BusquedaProd;
import vista.ModifProd;
import vista.ProdReqPedido;
import vista.Ventana;

public class Controlador implements ActionListener {

	private Ventana ventanaPrincipal;
	private ControladorUsuario contrUser;

	private final BusquedaProd dialogo;
	private final AgregarProd agregar;
	private final ModifProd modificar;
	private final ProdReqPedido prodReqPedido;

	public static enum Acciones {

		BTNAGREGARPROD, BTNBUSCARPROD, BTNVERREQPED, BTNVERUSER, BTNLOGIN, BTNCERRARSESION, BTNSALIRPROG, BTNMODIFICARBP, BTNELIMINARBP, BTNBUSCARBP, BTNREGISTRARBP, BTNGUARDARPROD
	}

	public Controlador() {
		// Inicializacion
		this.ventanaPrincipal = new Ventana();
		this.ventanaPrincipal.setVisible(true);
		this.dialogo = new BusquedaProd(this.ventanaPrincipal, true);
		this.agregar = new AgregarProd(this.dialogo);
		this.modificar = new ModifProd(this.dialogo);
		this.prodReqPedido = new ProdReqPedido(this.ventanaPrincipal, true);

		// PRINCIPAL
		this.ventanaPrincipal.getMntmAgregarProducto().setActionCommand(Acciones.BTNAGREGARPROD.name());
		this.ventanaPrincipal.getMntmAgregarProducto().addActionListener(this);
		this.ventanaPrincipal.getMntmBuscarProductos().setActionCommand(Acciones.BTNBUSCARPROD.name());
		this.ventanaPrincipal.getMntmBuscarProductos().addActionListener(this);
		this.ventanaPrincipal.getMntmVerReqPedido().setActionCommand(Acciones.BTNVERREQPED.name());
		this.ventanaPrincipal.getMntmVerReqPedido().addActionListener(this);
		this.ventanaPrincipal.getMntmVerUsuarios().setActionCommand(Acciones.BTNVERUSER.name());
		this.ventanaPrincipal.getMntmVerUsuarios().addActionListener(this);
		this.ventanaPrincipal.getBtnEntrar().setActionCommand(Acciones.BTNLOGIN.name());
		this.ventanaPrincipal.getBtnEntrar().addActionListener(this);
		this.ventanaPrincipal.getBtnCerrarSesin().setActionCommand(Acciones.BTNCERRARSESION.name());
		this.ventanaPrincipal.getBtnCerrarSesin().addActionListener(this);
		this.ventanaPrincipal.getBtnSalir().setActionCommand(Acciones.BTNSALIRPROG.name());
		this.ventanaPrincipal.getBtnSalir().addActionListener(this);

		// PROD
		this.dialogo.getBtnAgregar().setActionCommand(Acciones.BTNAGREGARPROD.name());
		this.dialogo.getBtnAgregar().addActionListener(this);
		this.dialogo.getBtnBuscar().setActionCommand(Acciones.BTNBUSCARBP.name());
		this.dialogo.getBtnBuscar().addActionListener(this);
		this.dialogo.getBtnEliminar().setActionCommand(Acciones.BTNELIMINARBP.name());
		this.dialogo.getBtnEliminar().addActionListener(this);
		this.dialogo.getBtnModificar().setActionCommand(Acciones.BTNMODIFICARBP.name());
		this.dialogo.getBtnModificar().addActionListener(this);
		this.agregar.getBtnAgregar().setActionCommand(Acciones.BTNREGISTRARBP.name());
		this.agregar.getBtnAgregar().addActionListener(this);
		this.modificar.getBtnGuardar().setActionCommand(Acciones.BTNGUARDARPROD.name());
		this.modificar.getBtnGuardar().addActionListener(this);
	}

	private void updatePuntoPedido(String[] prod) {
		try {
			PuntoPedido.verificarPuntoPedido(prod);
			this.prodReqPedido.setModelo(ProductoDataAccess.bajarTablaReqPedido());
			this.prodReqPedido.getTableProductos().setModel(this.prodReqPedido.getModelo());
		} catch (PuntoPedido e1) {
			prodReqPedido.getModelo().addRow(prod);
			prodReqPedido.getTableProductos().setModel(prodReqPedido.getModelo());
		}
	}

	// ActionPerformed
	@Override
	public void actionPerformed(ActionEvent e) {
		switch (Acciones.valueOf(e.getActionCommand())) {

		case BTNLOGIN:

			// TEST
			UsuarioDataAccess.usuarioActual = new Usuario("Ignacio", "Casal", "ignaciocasal_",
					"827ccb0eea8a706c4c34a16891f84e7b", true, true);
					//

			/*
			 * String idUser = this.ventanaPrincipal.getTfId().getText();
			 * 
			 * @SuppressWarnings("deprecation") String passUser =
			 * MD5.crypt(this.ventanaPrincipal.getPasswordField().getText());
			 * String[] userLogin = UsuarioDataAccess.buscarUsuarioID(idUser);
			 * if (userLogin == null) { JOptionPane.showMessageDialog(null,
			 * "Usuario invalido. Por favor verifique que el ID ingresado sea valido."
			 * , "Error Login", JOptionPane.WARNING_MESSAGE);
			 * this.ventanaPrincipal.getTfId().selectAll();
			 * this.ventanaPrincipal.getPasswordField().removeAll(); } else { if
			 * (userLogin[3].equals((passUser))) {
			 * UsuarioDataAccess.usuarioActual = new Usuario();
			 * UsuarioDataAccess.usuarioActual.setnombreUser(userLogin[0]);
			 * UsuarioDataAccess.usuarioActual.setapellidoUser(userLogin[1]);
			 * UsuarioDataAccess.usuarioActual.setidUser(userLogin[2]);
			 * UsuarioDataAccess.usuarioActual.setpassUser(userLogin[3]);
			 * UsuarioDataAccess.usuarioActual.setIsActivo(Boolean.valueOf(
			 * userLogin[4])); if (userLogin[5].equals("t")) {
			 * UsuarioDataAccess.usuarioActual.setIsAdmin(true); } else {
			 * UsuarioDataAccess.usuarioActual.setIsAdmin(false); }
			 */

			this.ventanaPrincipal.getPanelLogin().setVisible(false);
			this.ventanaPrincipal.getScrollPane().setVisible(true);
			this.ventanaPrincipal.getTableProductos().setVisible(true);
			this.ventanaPrincipal.getMnProducto().setEnabled(true);
			this.ventanaPrincipal.getMnUsuarios().setEnabled(true);
			if (UsuarioDataAccess.usuarioActual.getIsAdmin() == false) {
				this.ventanaPrincipal.getMntmAgregarProducto().setEnabled(false);
			}
			this.ventanaPrincipal.setModelo(ProductoDataAccess.bajarTablaActivos());
			this.ventanaPrincipal.getTableProductos().setModel(this.ventanaPrincipal.getModelo());
			this.prodReqPedido.setModelo(ProductoDataAccess.bajarTablaReqPedido());
			this.prodReqPedido.getTableProductos().setModel(this.prodReqPedido.getModelo());
			this.ventanaPrincipal.getLblSesion()
					.setText("Ha iniciado sesion como: " + UsuarioDataAccess.usuarioActual.getnombreUser() + " "
							+ UsuarioDataAccess.usuarioActual.getapellidoUser());
			this.ventanaPrincipal.getLblSesion().setVisible(true);
			this.ventanaPrincipal.getBtnCerrarSesin().setVisible(true);
			// } else {
			// JOptionPane.showMessageDialog(null, "Contrase�a incorrecta. Por
			// favor ingresela nuevamente",
			// "Error Login", JOptionPane.WARNING_MESSAGE);
			// this.ventanaPrincipal.getPasswordField().selectAll();
			//
			// }
			//
			// }

			break;

		case BTNAGREGARPROD:

			this.agregar.setVisible(true);

			break;

		case BTNBUSCARPROD:
			this.dialogo.getTableProductos().setModel(ProductoDataAccess.bajarTabla());
			if (UsuarioDataAccess.usuarioActual.getIsAdmin() == false) {
				this.dialogo.getPanel().setVisible(false);
			}
			this.dialogo.setVisible(true);

			break;

		case BTNVERREQPED:
			this.prodReqPedido.getTableProductos().setModel(prodReqPedido.getModelo());
			this.prodReqPedido.setVisible(true);

			break;

		case BTNVERUSER:
			contrUser = new ControladorUsuario();
			this.contrUser.getDialogUser().getTableUsuarios().setModel(UsuarioDataAccess.bajarTabla());
			this.contrUser.getDialogUser().setVisible(true);

			break;

		case BTNCERRARSESION:
			if (JOptionPane.showConfirmDialog(this.ventanaPrincipal, "�Esta seguro que desea cerrar sesi�n?",
					"Cerrar Sesi�n", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == 0) {
				UsuarioDataAccess.usuarioActual = null;
				this.ventanaPrincipal.getScrollPane().setVisible(false);
				this.ventanaPrincipal.getLblSesion().setVisible(false);
				this.ventanaPrincipal.getBtnCerrarSesin().setVisible(false);
				this.ventanaPrincipal.getMnProducto().setEnabled(false);
				this.ventanaPrincipal.getMnUsuarios().setEnabled(false);
				this.ventanaPrincipal.getPanelLogin().setVisible(true);
			}

			break;

		case BTNSALIRPROG:
			if (JOptionPane.showConfirmDialog(this.ventanaPrincipal, "�Esta seguro que desea salir?", "Exit",
					JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == 0) {
				ventanaPrincipal.dispose();
			}

			break;

		// BUSQ PROD
		case BTNBUSCARBP:
			String busqueda;
			String[] res = null;
			ArrayList<String[]> ray = new ArrayList<String[]>();
			busqueda = this.dialogo.getTextField().getText();
			DataAccess.limpiarTabla(dialogo.getTableProductos());
			if (this.dialogo.getComboBox().getSelectedItem().equals("ID")) {
				res = ProductoDataAccess.buscarProductoID(Integer.parseInt(busqueda));
				this.dialogo.getModelo().addRow(res);
				this.dialogo.getTableProductos().setModel(dialogo.getModelo());
			} else {
				if (this.dialogo.getComboBox().getSelectedItem().equals("Nombre")) {
					ray = (ProductoDataAccess.buscarProductoNombre(busqueda));
					for (String[] producto : ray) {
						this.dialogo.getModelo().addRow(producto);
					}
					this.dialogo.getTableProductos().setModel(dialogo.getModelo());

				} else if (this.dialogo.getComboBox().getSelectedItem().equals("Precio")) {
					ProductoDataAccess.buscarProductoPrecio(busqueda);
					ray = (ProductoDataAccess.buscarProductoPrecio(busqueda));
					for (String[] producto : ray) {
						this.dialogo.getModelo().addRow(producto);
					}
					this.dialogo.getTableProductos().setModel(dialogo.getModelo());
				} else {
					JOptionPane.showMessageDialog(this.dialogo, "Por favor seleccione un criterio de b�squeda",
							"Atenci�n", JOptionPane.WARNING_MESSAGE);
					this.dialogo.setModelo(ProductoDataAccess.bajarTabla());
					this.dialogo.getTableProductos().setModel(dialogo.getModelo());
				}

			}
			if (ray.isEmpty() && res == null) {
				JOptionPane.showMessageDialog(this.dialogo, "No se encontraron resultados", "Atenci�n",
						JOptionPane.WARNING_MESSAGE);
			}
			break;

		case BTNELIMINARBP:
			if (this.dialogo.getTableProductos().getSelectedRowCount() == 0) {
				JOptionPane.showMessageDialog(this.dialogo,
						"Por favor seleccione al menos un producto que desee eliminar", "Atenci�n",
						JOptionPane.WARNING_MESSAGE);
			} else {
				if (JOptionPane.showConfirmDialog(this.dialogo, "�Esta seguro que desea eliminar?",
						"Confirmar Eliminaci�n", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == 0) {
					Integer fila = this.dialogo.getTableProductos().getSelectedRow();
					ProductoDataAccess.eliminarProducto(
							Integer.valueOf(dialogo.getTableProductos().getValueAt(fila, 2).toString()));
					JOptionPane.showMessageDialog(this.dialogo, " Se ha Eliminado Correctamente", "Informaci�n",
					JOptionPane.INFORMATION_MESSAGE);
					dialogo.setModelo(ProductoDataAccess.bajarTabla());
					dialogo.getTableProductos().setModel(dialogo.getModelo());
					this.ventanaPrincipal.setModelo(ProductoDataAccess.bajarTablaActivos());
					this.ventanaPrincipal.getTableProductos().setModel(this.ventanaPrincipal.getModelo());

				}
			}

			break;

		case BTNMODIFICARBP:
			if (this.dialogo.getTableProductos().getSelectedRowCount() == 0) {
				JOptionPane.showMessageDialog(this.dialogo,
						"Por favor seleccione al menos un usuario que desee modificar", "Atenci�n",
						JOptionPane.WARNING_MESSAGE);
			} else {
				Integer fila = this.dialogo.getTableProductos().getSelectedRow();
				String[] prodArray = ProductoDataAccess
						.buscarProductoID(Integer.valueOf(dialogo.getTableProductos().getValueAt(fila, 2).toString()));

				this.modificar.getTfNombre().setText(prodArray[0]);
				this.modificar.getTfMarca().setText(prodArray[1]);
				this.modificar.getTfId().setText(prodArray[2]);
				this.modificar.getTfPrecio().setText(prodArray[3]);
				this.modificar.getSpCant().setValue(Integer.valueOf(prodArray[4]));
				Boolean active;
				if (prodArray[5].equals("t")) {
					active = true;
				} else {
					active = false;
				}
				this.modificar.getChckbxActivo().setSelected(active);
				this.modificar.getTfPuntoPedido().setText(prodArray[6]);
				if (UsuarioDataAccess.usuarioActual.getIsAdmin() == false) {
					this.modificar.getTfNombre().setEditable(false);
					this.modificar.getTfMarca().setEditable(false);
					this.modificar.getTfId().setEditable(false);
					this.modificar.getTfPrecio().setEditable(false);
					this.modificar.getTfPuntoPedido().setEditable(false);
					this.modificar.getChckbxActivo().setEnabled(false);

				}
				this.modificar.setVisible(true);
			}
			break;

		case BTNGUARDARPROD:
			Producto prodModif = new Producto();
			prodModif.setNombreProd(this.modificar.getTfNombre().getText());
			prodModif.setMarcaProd(this.modificar.getTfMarca().getText());
			prodModif.setIdProducto(Integer.valueOf(this.modificar.getTfId().getText()));
			prodModif.setPrecioProd(Double.valueOf(this.modificar.getTfPrecio().getText()));
			prodModif.setCantidadProd(Integer.valueOf(this.modificar.getSpCant().getValue().toString()));
			prodModif.setIsActivo(this.modificar.getChckbxActivo().isSelected());
			prodModif.setPuntoPedido(Integer.valueOf(this.modificar.getTfPuntoPedido().getText()));

			if (ProductoDataAccess.buscarProductoID(prodModif.getIdProducto()) == null) {
				ProductoDataAccess.modificarProducto(prodModif, Integer.valueOf(this.modificar.getTfId().getText()));
				dialogo.setModelo(ProductoDataAccess.bajarTabla());
				dialogo.getTableProductos().setModel(dialogo.getModelo());
				this.ventanaPrincipal.setModelo(ProductoDataAccess.bajarTablaActivos());
				this.ventanaPrincipal.getTableProductos().setModel(this.ventanaPrincipal.getModelo());
				String[] prod = new String[7];
				prod[0] = prodModif.getNombre();
				prod[1] = prodModif.getMarcaProd();
				prod[2] = prodModif.getIdProducto().toString();
				prod[3] = prodModif.getPrecioProd().toString();
				prod[4] = prodModif.getCantidadProd().toString();
				prod[5] = prodModif.getPuntoPedido().toString();
				prod[6] = prodModif.getIsActivo().toString();			
				updatePuntoPedido(prod);
				this.modificar.setVisible(false);
			} else {
				if (JOptionPane.showConfirmDialog(this.modificar, "Los cambios se sobreescribir�n �Confirma la acci�n?",
						"Atenci�n", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == 0) {
					ProductoDataAccess.modificarProducto(prodModif,
							Integer.valueOf(this.modificar.getTfId().getText()));
					dialogo.setModelo(ProductoDataAccess.bajarTabla());
					dialogo.getTableProductos().setModel(dialogo.getModelo());
					this.ventanaPrincipal.setModelo(ProductoDataAccess.bajarTablaActivos());
					this.ventanaPrincipal.getTableProductos().setModel(this.ventanaPrincipal.getModelo());
					this.modificar.setVisible(false);
				}
			}

			break;

		case BTNREGISTRARBP:
			Producto newProd = new Producto();
			newProd.setNombreProd(this.agregar.getTfNombre().getText());
			newProd.setMarcaProd(this.agregar.getTfMarca().getText());
			newProd.setIdProducto(Integer.parseInt(this.agregar.getTfId().getText()));
			newProd.setCantidadProd(Integer.parseInt(this.agregar.getTfCant().getText()));
			newProd.setPrecioProd(Double.valueOf(this.agregar.getTfPrecio().getText()));
			newProd.setIsActivo(true);
			newProd.setPuntoPedido(Integer.parseInt(this.agregar.getTfPuntoPedido().getText()));

			if (ProductoDataAccess.buscarProductoID(newProd.getIdProducto()) == null) {
				ProductoDataAccess.registrarProducto(newProd);
				String[] prod1 = new String[6];
				prod1[0] = newProd.getNombre();
				prod1[1] = newProd.getMarcaProd();
				prod1[2] = String.valueOf(newProd.getIdProducto());
				prod1[4] = String.valueOf(newProd.getCantidadProd());
				prod1[3] = String.valueOf(newProd.getPrecioProd());
				prod1[5] = String.valueOf(newProd.getPuntoPedido());
				dialogo.setModelo(ProductoDataAccess.bajarTabla());
				dialogo.getTableProductos().setModel(dialogo.getModelo());
				this.ventanaPrincipal.getModelo().addRow(prod1);
				this.ventanaPrincipal.getTableProductos().setModel(this.ventanaPrincipal.getModelo());
				this.agregar.setVisible(false);
				updatePuntoPedido(prod1);
			} else {
				if (JOptionPane.showConfirmDialog(this.agregar,
						"Un producto con el mismo ID ya existe en su inventario �Desea sobreescribirlo?", "Atenci�n",
						JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) == 0) {
					ProductoDataAccess.modificarProducto(newProd,newProd.getIdProducto());
					dialogo.setModelo(ProductoDataAccess.bajarTabla());
					dialogo.getTableProductos().setModel(dialogo.getModelo());
					this.ventanaPrincipal.setModelo(ProductoDataAccess.bajarTablaActivos());
					this.ventanaPrincipal.getTableProductos().setModel(this.ventanaPrincipal.getModelo());
				}
			}
			break;
		}
	}
}
