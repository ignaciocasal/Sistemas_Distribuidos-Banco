package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

public class ProdReqPedido extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JTable tableProductos;
	private JScrollPane scrollPane;
	private DefaultTableModel modelo;

	/**
	 * Create the dialog.
	 */
	public ProdReqPedido(java.awt.Frame parent, boolean modal) {
		super(parent, modal);
		Integer ancho = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
		Integer alto = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;
		this.setBounds((ancho / 2) - (450 / 2), (alto / 2) - (300 / 2), 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel lblProductosQueRequieren = new JLabel("Productos que requieren pedido");
			lblProductosQueRequieren.setFont(new Font("Calibri", Font.BOLD, 14));
			lblProductosQueRequieren.setBounds(10, 11, 243, 23);
			contentPanel.add(lblProductosQueRequieren);
		}

		// TABLA PRODUCTOS
		String datos[][] = {};
		String cabecera[] = { "Nombre", "Marca", "ID", "Precio", "Stock", "Activo", "Punto Pedido" };

		modelo = new DefaultTableModel(datos, cabecera);
		// modelo.addRow(productos a pedir);
		tableProductos = new JTable();
		tableProductos.setEnabled(false);
		tableProductos.setModel(modelo);

		scrollPane = new JScrollPane(tableProductos);
		scrollPane.setBounds(10, 45, 414, 205);
		contentPanel.add(scrollPane);
		tableProductos.setOpaque(false);
		tableProductos.setAutoCreateRowSorter(true);
		tableProductos.setBorder(new LineBorder(new Color(0, 0, 0)));
		tableProductos.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		tableProductos.setBounds(10, 59, 391, 147);
	}

	public DefaultTableModel getModelo() {
		return modelo;
	}

	public void setModelo(DefaultTableModel modelo) {
		this.modelo = modelo;
	}

	public JTable getTableProductos() {
		return tableProductos;
	}
}
