package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.DecimalFormat;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JCheckBox;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

public class ModifProd extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JTextField tfNombre;
	private JTextField tfMarca;
	private JTextField tfId;
	private JButton btnGuardar;
	private JFormattedTextField tfPrecio;
	private JTextField tfPuntoPedido;
	private JLabel lblPuntoPedido;
	private JCheckBox chckbxActivo;
	private JSpinner spCant;

	/**
	 * Create the dialog.
	 */
	public ModifProd(java.awt.Dialog parent) {
		super(parent);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setType(Type.UTILITY);
		setForeground(Color.BLACK);
		setTitle("Modificar Usuario");
		setResizable(false);
		Integer ancho = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
		Integer alto = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;
		this.setBounds((ancho / 2) - (244 / 2), (alto / 2) - (300 / 2), 244, 300);

		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JLabel lblModifiqueLosDatos = new JLabel("Modifique los datos del producto");
		lblModifiqueLosDatos.setFont(new Font("Calibri", Font.BOLD, 14));
		lblModifiqueLosDatos.setBounds(10, 24, 212, 14);
		contentPanel.add(lblModifiqueLosDatos);

		btnGuardar = new JButton("Guardar");
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnGuardar.setBounds(74, 245, 89, 23);
		contentPanel.add(btnGuardar);

		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setBounds(20, 67, 70, 14);
		contentPanel.add(lblNombre);

		JLabel lblMarca = new JLabel("Marca:");
		lblMarca.setBounds(20, 92, 70, 14);
		contentPanel.add(lblMarca);

		JLabel lblId = new JLabel("ID:");
		lblId.setBounds(20, 117, 70, 14);
		contentPanel.add(lblId);

		JLabel lblPrecio = new JLabel("Precio:");
		lblPrecio.setBounds(20, 142, 70, 14);
		contentPanel.add(lblPrecio);

		tfNombre = new JTextField();
		tfNombre.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Integer limite = 20;
				if (tfNombre.getText().length() == limite) {
					e.consume();
				}
			}
		});
		tfNombre.setBounds(93, 64, 100, 20);
		contentPanel.add(tfNombre);
		tfNombre.setColumns(10);

		tfMarca = new JTextField();
		tfMarca.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Integer limite = 15;
				if (tfNombre.getText().length() == limite) {
					e.consume();
				}
			}
		});
		tfMarca.setColumns(10);
		tfMarca.setBounds(93, 89, 100, 20);
		contentPanel.add(tfMarca);

		tfId = new JTextField();
		tfId.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if (!(Character.isDigit(c))) {
					// getToolkit().beep();
					e.consume();
				}
			}
		});
		tfId.setColumns(10);
		tfId.setBounds(93, 114, 100, 20);
		contentPanel.add(tfId);

		JLabel lblCantidad = new JLabel("Cantidad:");
		lblCantidad.setBounds(20, 170, 70, 14);
		contentPanel.add(lblCantidad);

		DecimalFormat decimales = new DecimalFormat("0.00");
		tfPrecio = new JFormattedTextField(decimales);

		tfPrecio.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e) {
				char c = e.getKeyChar();
				if (c >= 32 && c <= 45) {
					// getToolkit().beep();
					e.consume();
				}
			}
		});
		tfPrecio.setBounds(93, 139, 100, 20);
		contentPanel.add(tfPrecio);

		tfPuntoPedido = new JTextField();
		tfPuntoPedido.setColumns(10);
		tfPuntoPedido.setBounds(93, 195, 100, 20);
		contentPanel.add(tfPuntoPedido);

		lblPuntoPedido = new JLabel("Punto Pedido:");
		lblPuntoPedido.setBounds(20, 198, 70, 14);
		contentPanel.add(lblPuntoPedido);

		chckbxActivo = new JCheckBox("Activo");
		chckbxActivo.setSelected(true);
		chckbxActivo.setBounds(93, 218, 97, 23);
		contentPanel.add(chckbxActivo);

		spCant = new JSpinner();
		spCant.setModel(new SpinnerNumberModel(new Integer(0), new Integer(0), null, new Integer(1)));
		spCant.setBounds(93, 167, 100, 20);
		contentPanel.add(spCant);
	}

	public JTextField getTfNombre() {
		return tfNombre;
	}

	public JTextField getTfMarca() {
		return tfMarca;
	}

	public JTextField getTfId() {
		return tfId;
	}

	public JButton getBtnGuardar() {
		return btnGuardar;
	}

	public void setBtnGuardar(JButton btnAgregar) {
		this.btnGuardar = btnAgregar;
	}

	public void setTfNombre(JTextField tfNombre) {
		this.tfNombre = tfNombre;
	}

	public void setTfMarca(JTextField tfMarca) {
		this.tfMarca = tfMarca;
	}

	public void setTfId(JTextField tfId) {
		this.tfId = tfId;
	}

	public JFormattedTextField getTfPrecio() {
		return tfPrecio;
	}

	public void setTfPrecio(JFormattedTextField tfPrecio) {
		this.tfPrecio = tfPrecio;
	}

	public JTextField getTfPuntoPedido() {
		return tfPuntoPedido;
	}

	public void setTfPuntoPedido(JTextField tfPuntoPedido) {
		this.tfPuntoPedido = tfPuntoPedido;
	}

	public JLabel getLblPuntoPedido() {
		return lblPuntoPedido;
	}

	public void setLblPuntoPedido(JLabel lblPuntoPedido) {
		this.lblPuntoPedido = lblPuntoPedido;
	}

	public JCheckBox getChckbxActivo() {
		return chckbxActivo;
	}

	public void setChckbxActivo(JCheckBox chckbxActivo) {
		this.chckbxActivo = chckbxActivo;
	}

	public JSpinner getSpCant() {
		return spCant;
	}
}