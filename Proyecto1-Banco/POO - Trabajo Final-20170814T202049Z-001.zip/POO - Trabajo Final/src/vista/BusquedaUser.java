package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

public class BusquedaUser extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private final JPanel contentPanel = new JPanel();
	private JTextField txtFieldUsuario;
	private JTable tableUsuarios;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JRadioButton rdbtnId;
	private JRadioButton rdbtnApellido;
	private JButton btnBuscar;
	private JScrollPane scrollPane;
	private JButton btnAgregar;
	private JButton btnModificar;
	private JButton btnEliminar;
	private DefaultTableModel modelo;
	private JButton btnFinalizar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			BusquedaUser dialog = new BusquedaUser();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */

	public BusquedaUser() {
		// setModal(true);
		setModalExclusionType(ModalExclusionType.APPLICATION_EXCLUDE);
		setType(Type.UTILITY);
		setTitle("Usuarios");
		Integer ancho = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
		Integer alto = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;
		this.setBounds((ancho / 2) - (500 / 2), (alto / 2) - (300 / 2), 500, 300);

		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JLabel lblBuscar = new JLabel("Buscar:");
		lblBuscar.setBounds(20, 14, 46, 14);
		contentPanel.add(lblBuscar);

		txtFieldUsuario = new JTextField();
		txtFieldUsuario.setBounds(76, 11, 145, 20);
		contentPanel.add(txtFieldUsuario);
		txtFieldUsuario.setColumns(10);

		rdbtnId = new JRadioButton("ID");
		rdbtnId.setBounds(236, 10, 46, 23);
		buttonGroup.add(rdbtnId);
		contentPanel.add(rdbtnId);

		rdbtnApellido = new JRadioButton("Apellido");
		rdbtnApellido.setBounds(290, 10, 76, 23);
		buttonGroup.add(rdbtnApellido);
		contentPanel.add(rdbtnApellido);

		btnBuscar = new JButton("Buscar");
		btnBuscar.setBounds(372, 10, 98, 23);
		contentPanel.add(btnBuscar);

		JPanel ButtonPanel = new JPanel();
		ButtonPanel.setBounds(0, 217, 474, 33);
		contentPanel.add(ButtonPanel);
		ButtonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

		btnAgregar = new JButton("Agregar...");
		ButtonPanel.add(btnAgregar);

		btnModificar = new JButton("Modificar...");
		ButtonPanel.add(btnModificar);

		btnEliminar = new JButton("Eliminar");
		btnEliminar.setVisible(false);
		ButtonPanel.add(btnEliminar);

		btnFinalizar = new JButton("Finalizar");
		btnFinalizar.setVisible(false);
		ButtonPanel.add(btnFinalizar);

		String datos[][] = {};
		String cabecera[] = { "Nombre", "Apellido", "ID", "Pass", "Admin", "Activo" };

		modelo = new DefaultTableModel(datos, cabecera);

		// TABLA USUARIOS
		tableUsuarios = new JTable();
		tableUsuarios.setOpaque(false);
		tableUsuarios.setModel(modelo);
		scrollPane = new JScrollPane(tableUsuarios);
		scrollPane.setBounds(10, 53, 464, 157);
		contentPanel.add(scrollPane);
		tableUsuarios.setAutoCreateRowSorter(true);
		tableUsuarios.setBorder(new LineBorder(new Color(0, 0, 0)));
		tableUsuarios.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tableUsuarios.setBounds(10, 59, 391, 147);
	}

	public JButton getBtnFinalizar() {
		return btnFinalizar;
	}

	public Boolean algunRowSelected(JTable table) {
		Boolean flag = false;
		for (int i = 0; i < table.getRowCount(); i++) {
			if (this.tableUsuarios.isRowSelected(i)) {
				return flag = true;
			}
		}
		return flag;
	}

	// GETTERS AND SETTERS
	public JTextField getTxtFieldUsuario() {
		return txtFieldUsuario;
	}

	public void setTxtFieldUsuario(JTextField txtFieldUsuario) {
		this.txtFieldUsuario = txtFieldUsuario;
	}

	public JTable getTableUsuarios() {
		return tableUsuarios;
	}

	public void setTableUsuarios(JTable tableUsuarios) {
		this.tableUsuarios = tableUsuarios;
	}

	public JRadioButton getRdbtnId() {
		return rdbtnId;
	}

	public void setRdbtnId(JRadioButton rdbtnId) {
		this.rdbtnId = rdbtnId;
	}

	public JRadioButton getRdbtnNombre() {
		return rdbtnApellido;
	}

	public void setRdbtnNombre(JRadioButton rdbtnNombre) {
		this.rdbtnApellido = rdbtnNombre;
	}

	public JButton getBtnBuscar() {
		return btnBuscar;
	}

	public void setBtnBuscar(JButton btnBuscar) {
		this.btnBuscar = btnBuscar;
	}

	public JScrollPane getScrollPane() {
		return scrollPane;
	}

	public void setScrollPane(JScrollPane scrollPane) {
		this.scrollPane = scrollPane;
	}

	public JButton getBtnAgregar() {
		return btnAgregar;
	}

	public void setBtnAgregar(JButton btnAgregar) {
		this.btnAgregar = btnAgregar;
	}

	public JButton getBtnModificar() {
		return btnModificar;
	}

	public void setBtnModificar(JButton btnModificar) {
		this.btnModificar = btnModificar;
	}

	public JButton getBtnEliminar() {
		return btnEliminar;
	}

	public void setBtnEliminar(JButton btnEliminar) {
		this.btnEliminar = btnEliminar;
	}

	public DefaultTableModel getModelo() {
		return modelo;
	}

	public void setModelo(DefaultTableModel modelo) {
		this.modelo = modelo;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
}
