package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

public class BusquedaProd extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private final JPanel contentPanel = new JPanel();

	private JTextField textField;
	private JTable tableProductos;
	private JButton btnBuscar;
	private JComboBox<String> comboBox;
	private JScrollPane scrollPane;
	private JButton btnAgregar;
	private JButton btnModificar;
	private JButton btnEliminar;
	private JPanel panel;
	private DefaultTableModel modelo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			BusquedaProd dialog = new BusquedaProd();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public BusquedaProd() {
		
		
	}

	public BusquedaProd(java.awt.Frame parent, boolean modal) {
		super(parent, modal);
		setModalExclusionType(ModalExclusionType.APPLICATION_EXCLUDE);
		setTitle("B\u00FAsqueda de Productos");
		setType(Type.UTILITY);
		Integer ancho = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
		Integer alto = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;
		this.setBounds((ancho / 2) - (500 / 2), (alto / 2) - (300 / 2), 500, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setToolTipText("");
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		{
			JLabel label = new JLabel("Buscar:");
			label.setBounds(20, 14, 46, 14);
			contentPanel.add(label);
		}
		{
			textField = new JTextField();
			textField.setColumns(10);
			textField.setBounds(76, 11, 145, 20);
			contentPanel.add(textField);
		}
		{
			btnBuscar = new JButton("Buscar");
			btnBuscar.setBounds(385, 10, 89, 23);
			contentPanel.add(btnBuscar);
		}
		{
			comboBox = new JComboBox<String>();
			comboBox.setToolTipText("Seleccione una opci\u00F3n de b\u00FAsqueda");
			comboBox.setModel(new DefaultComboBoxModel<String>(new String[] { "Por..", "ID", "Nombre", "Precio" }));
			comboBox.setBounds(260, 13, 89, 17);
			contentPanel.add(comboBox);
		}

		panel = new JPanel();
		panel.setBounds(0, 217, 474, 33);
		contentPanel.add(panel);
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));

		btnAgregar = new JButton("Agregar...");
		panel.add(btnAgregar);

		btnEliminar = new JButton("Eliminar");

		btnModificar = new JButton("Modificar...");
		panel.add(btnModificar);
		panel.add(btnEliminar);

		// TABLA PRODUCTOS
		String datos[][] = {};
		String cabecera[] = { "Nombre", "Marca", "ID", "Precio", "Stock", "Activo", "Punto Pedido" };
		//
		modelo = new DefaultTableModel(datos, cabecera);
		tableProductos = new JTable();
		tableProductos.setModel(modelo);

		scrollPane = new JScrollPane(tableProductos);
		scrollPane.setBounds(10, 53, 464, 157);
		contentPanel.add(scrollPane);
		tableProductos.setOpaque(false);
		tableProductos.setAutoCreateRowSorter(true);
		tableProductos.setBorder(new LineBorder(new Color(0, 0, 0)));
		tableProductos.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		tableProductos.setBounds(10, 59, 391, 147);
	}

	// GETTERS AND SETTERS
	public JTextField getTextField() {
		return textField;
	}

	public void setTextField(JTextField textField) {
		this.textField = textField;
	}

	public JButton getBtnBuscar() {
		return btnBuscar;
	}

	public JButton getBtnAgregar() {
		return btnAgregar;
	}

	public JButton getBtnModificar() {
		return btnModificar;
	}

	public JButton getBtnEliminar() {
		return btnEliminar;
	}

	public JComboBox<String> getComboBox() {
		return comboBox;
	}

	public void setComboBox(JComboBox<String> comboBox) {
		this.comboBox = comboBox;
	}

	public JTable getTableProductos() {
		return tableProductos;
	}

	public void setTableProductos(JTable tableProductos) {
		this.tableProductos = tableProductos;
	}

	public DefaultTableModel getModelo() {
		return modelo;
	}

	public void setModelo(DefaultTableModel modelo) {
		this.modelo = modelo;
	}

	public JPanel getPanel() {
		return panel;
	}

}
