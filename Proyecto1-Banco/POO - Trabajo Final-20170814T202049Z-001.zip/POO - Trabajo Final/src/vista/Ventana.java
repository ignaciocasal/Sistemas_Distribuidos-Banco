package vista;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;

public class Ventana extends JFrame {

	private static final long serialVersionUID = 1L;

	private JPanel contentPane;
	private JMenuBar menuBar;
	private JMenu mnUsuarios;
	private JMenu mnProducto;
	private JMenuItem mntmAgregarProducto;
	private JTextField tfId;
	private JPasswordField passwordField;
	private JTable tableProductos;
	private JMenuItem mntmBuscarProductos;
	private JMenuItem mntmVerUsuarios;
	private JLabel lblLogin;
	private JPanel panelLogin;
	private JLabel lblId;
	private JLabel lblPass;
	private JButton btnEntrar;
	private JScrollPane scrollPane;
	private JLabel lblSesion;
	private JButton btnCerrarSesin;
	private JButton btnSalir;
	private JMenuItem mntmVerReqPedido;

	private DefaultTableModel modelo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventana frame = new Ventana();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ventana() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		Integer ancho = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
		Integer alto = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;
		this.setBounds((ancho / 2) - (800 / 2), (alto / 2) - (500 / 2), 800, 500);

		menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		mnProducto = new JMenu("Producto");
		mnProducto.setEnabled(false);
		menuBar.add(mnProducto);

		mntmAgregarProducto = new JMenuItem("Agregar Producto...");
		mnProducto.add(mntmAgregarProducto);

		mntmBuscarProductos = new JMenuItem("Buscar Productos...");
		mnProducto.add(mntmBuscarProductos);

		mntmVerReqPedido = new JMenuItem("Ver Requieren pedido...");
		mnProducto.add(mntmVerReqPedido);

		mnUsuarios = new JMenu("Usuarios");
		mnUsuarios.setEnabled(false);
		menuBar.add(mnUsuarios);

		mntmVerUsuarios = new JMenuItem("Ver Usuarios...");
		mnUsuarios.add(mntmVerUsuarios);

		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		tableProductos = new JTable();
		tableProductos.setEnabled(false);
		tableProductos.setVisible(false);
		Object[][] datos = {};
		String[] cabecera = { "ID", "Nombre", "Marca", "Precio", "Stock" };

		modelo = new DefaultTableModel(datos, cabecera);
		tableProductos.setModel(modelo);
		scrollPane = new JScrollPane(tableProductos);
		scrollPane.setVisible(false);
		scrollPane.setBounds(10, 42, 764, 387);
		contentPane.add(scrollPane);

		panelLogin = new JPanel();
		panelLogin.setBounds(283, 67, 181, 199);
		contentPane.add(panelLogin);
		panelLogin.setBackground(Color.WHITE);
		panelLogin.setBorder(new LineBorder(new Color(0, 0, 0)));
		panelLogin.setLayout(null);

		lblLogin = new JLabel("Login");
		lblLogin.setFont(new Font("Calibri", Font.BOLD, 17));
		lblLogin.setBounds(10, 11, 60, 23);
		panelLogin.add(lblLogin);

		lblId = new JLabel("ID:");
		lblId.setBounds(24, 66, 46, 14);
		panelLogin.add(lblId);

		lblPass = new JLabel("Pass:");
		lblPass.setBounds(24, 106, 46, 14);
		panelLogin.add(lblPass);

		tfId = new JTextField();
		tfId.setBounds(66, 63, 86, 23);
		panelLogin.add(tfId);
		tfId.setColumns(10);

		btnEntrar = new JButton("Entrar");
		btnEntrar.setBounds(47, 151, 89, 23);
		panelLogin.add(btnEntrar);

		passwordField = new JPasswordField();
		passwordField.setBounds(66, 103, 86, 23);
		panelLogin.add(passwordField);

		tableProductos.setRowSelectionAllowed(false);
		tableProductos.setAutoCreateRowSorter(true);
		tableProductos.setBorder(new LineBorder(new Color(0, 0, 0)));
		tableProductos.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		tableProductos.setBounds(10, 59, 391, 147);

		lblSesion = new JLabel("");
		lblSesion.setVisible(false);
		lblSesion.setBounds(181, 11, 345, 14);
		contentPane.add(lblSesion);

		btnSalir = new JButton("Salir");
		btnSalir.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnSalir.setForeground(Color.BLACK);
		btnSalir.setBounds(660, 7, 114, 23);
		contentPane.add(btnSalir);

		btnCerrarSesin = new JButton("Cerrar Sesi\u00F3n");
		btnCerrarSesin.setVisible(false);
		btnCerrarSesin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnCerrarSesin.setBounds(536, 7, 114, 23);
		contentPane.add(btnCerrarSesin);

	}

	public JMenuItem getMntmAgregarProducto() {
		return mntmAgregarProducto;
	}

	public JPasswordField getPasswordField() {
		return passwordField;
	}

	public JTable getTableProductos() {
		return tableProductos;
	}

	public JMenuItem getMntmBuscarProductos() {
		return mntmBuscarProductos;
	}

	public JMenuItem getMntmVerUsuarios() {
		return mntmVerUsuarios;
	}

	public JTextField getTfId() {
		return tfId;
	}

	public JPanel getPanelLogin() {
		return panelLogin;
	}

	public JButton getBtnEntrar() {
		return btnEntrar;
	}

	public JScrollPane getScrollPane() {
		return scrollPane;
	}

	public JMenu getMnUsuarios() {
		return mnUsuarios;
	}

	public JMenu getMnProducto() {
		return mnProducto;
	}

	public void setLblSesion(JLabel lblSesion) {
		this.lblSesion = lblSesion;
	}

	public JLabel getLblSesion() {
		return lblSesion;
	}

	public JButton getBtnCerrarSesin() {
		return btnCerrarSesin;
	}

	public JButton getBtnSalir() {
		return btnSalir;
	}

	public JMenuItem getMntmVerReqPedido() {
		return mntmVerReqPedido;
	}

	public DefaultTableModel getModelo() {
		return modelo;
	}

	public void setModelo(DefaultTableModel modelo) {
		this.modelo = modelo;
	}
}
