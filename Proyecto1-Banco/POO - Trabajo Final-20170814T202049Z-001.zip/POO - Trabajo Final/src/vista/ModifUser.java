package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class ModifUser extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JTextField tfNombre;
	private JTextField tfApellido;
	private JTextField tfId;
	private JPasswordField passwordField;
	private JButton btnGuardar;
	private JCheckBox chckbxAdmin;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			ModifUser dialog = new ModifUser();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	

	/**
	 * Create the dialog.
	 */
	public ModifUser() {
		setModal(true);
		setType(Type.UTILITY);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setForeground(Color.BLACK);
		setTitle("Modificar Usuario");
		setResizable(false);
		Integer ancho = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
		Integer alto = java.awt.Toolkit.getDefaultToolkit().getScreenSize().height;
		this.setBounds((ancho / 2) - (244 / 2), (alto / 2) - (273 / 2), 244, 273);

		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JLabel lblModifiqueLosDatos = new JLabel("Modifique los datos del usuario");
		lblModifiqueLosDatos.setFont(new Font("Calibri", Font.BOLD, 14));
		lblModifiqueLosDatos.setBounds(10, 24, 212, 14);
		contentPanel.add(lblModifiqueLosDatos);

		btnGuardar = new JButton("Guardar");
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnGuardar.setBounds(74, 202, 89, 23);
		contentPanel.add(btnGuardar);

		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setBounds(20, 67, 70, 14);
		contentPanel.add(lblNombre);

		JLabel lblApellido = new JLabel("Apellido:");
		lblApellido.setBounds(20, 92, 70, 14);
		contentPanel.add(lblApellido);

		JLabel lblId = new JLabel("ID:");
		lblId.setBounds(20, 117, 70, 14);
		contentPanel.add(lblId);

		JLabel lblContrasea = new JLabel("Contrase\u00F1a:");
		lblContrasea.setBounds(20, 142, 70, 14);
		contentPanel.add(lblContrasea);

		tfNombre = new JTextField();
		tfNombre.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Integer limite = 20;
				char c = e.getKeyChar();
				if (tfNombre.getText().length() == limite || !(Character.isLetter(c)) || (c == KeyEvent.VK_BACK_SPACE)
						|| (c == KeyEvent.VK_DELETE)) {
					e.consume();
				}
			}
		});
		tfNombre.setBounds(93, 64, 100, 20);
		contentPanel.add(tfNombre);
		tfNombre.setColumns(10);

		tfApellido = new JTextField();
		tfApellido.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Integer limite = 20;
				char c = e.getKeyChar();
				if (tfApellido.getText().length() == limite || !(Character.isLetter(c)) || (c == KeyEvent.VK_BACK_SPACE)
						|| (c == KeyEvent.VK_DELETE)) {
					e.consume();
				}
			}
		});
		tfApellido.setColumns(10);
		tfApellido.setBounds(93, 89, 100, 20);
		contentPanel.add(tfApellido);

		tfId = new JTextField();
		tfId.addKeyListener(new KeyAdapter() {
			@Override
			public void keyTyped(KeyEvent e) {
				Integer limite = 15;
				char c = e.getKeyChar();
				if (tfId.getText().length() == limite || (c == KeyEvent.VK_SPACE) || (c == KeyEvent.VK_BACK_SPACE)
						|| (c == KeyEvent.VK_DELETE)) {
					e.consume();
				}
			}
		});
		tfId.setColumns(10);
		tfId.setBounds(93, 114, 100, 20);
		contentPanel.add(tfId);

		passwordField = new JPasswordField();
		passwordField.setBounds(93, 139, 100, 20);
		contentPanel.add(passwordField);

		chckbxAdmin = new JCheckBox("Administrador");
		chckbxAdmin.setBounds(93, 166, 129, 23);
		contentPanel.add(chckbxAdmin);
	}

	public JButton getBtnRegistrar() {
		return btnGuardar;
	}
	public JCheckBox getChckbxAdmin() {
		return chckbxAdmin;
	}

	public void setChckbxAdmin(JCheckBox chckbxAdmin) {
		this.chckbxAdmin = chckbxAdmin;
	}

	public JTextField getTfNombre() {
		return tfNombre;
	}

	public JTextField getTfApellido() {
		return tfApellido;
	}

	public JTextField getTfId() {
		return tfId;
	}

	public JPasswordField getPasswordField() {
		return passwordField;
	}
}
